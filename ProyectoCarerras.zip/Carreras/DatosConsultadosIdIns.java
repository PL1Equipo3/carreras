import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;


public class DatosConsultadosIdIns extends JFrame {

	private JPanel contentPane;
	private static ConsultarInscripción  VConsuIn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DatosConsultadosIdIns frame = new DatosConsultadosIdIns(VConsuIn);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DatosConsultadosIdIns(ConsultarInscripción  VCI) {
		try {
			//Conexi�n a la BD
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Ruta absoluta o relativa como parámetro de getConnection
			Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
			final Statement s = conn.createStatement();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 535, 392);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		VCI=VConsuIn;
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.WEST);
		
		
		
		//Donde Escribiremos los datos
		JTextArea textDatos = new JTextArea();
		
		
		//Obtener los datos 
		try{
			//Obtenemos la competición de la que se quiere los datos mediante el Id_inscripción

			s.execute("SELECT Id_competición FROM Inscripción WHERE( Id_inscripción='" + VCI.tfIdInscripcion.getText() + "')"); 
			ResultSet CompeticionID = s.getResultSet(); 
			CompeticionID.next();
			
			// Se obtiene todos los datos de dicha competición

			s.execute("SELECT Nombre, Apellidos, [Id_inscripción], [Fecha inscripción], Estado, [Cuota abonada], [Forma de pago], Categoría "
					+ "FROM Atleta INNER JOIN Inscripción  "
					+ "ON Inscripción.Id_atleta=Atleta.DNI "
					+ "WHERE (Inscripción.Id_competición = '" + CompeticionID.getString(1) + "' AND Inscripción.Id_inscripción='" + VCI.tfIdInscripcion.getText() + "')");
			ResultSet resultado = s.getResultSet();
			resultado.next();
			//Mostramos al atleta los datos de su consulta

			String t ="Tus datos para la competción " + CompeticionID.getString(1) + " son los siguientes:";
			t = t + "\t" + "Nombre: "+ resultado.getString(1) + " \n" +
					"\t" + "Apellidos: " + resultado.getString(2) + " \n" + 
					"\t" + "Id_inscripción: " + resultado.getString(3) + " \n" +
					"\t" + "Fecha inscripción: " + resultado.getDate(4) + " \n" +
					"\t" + "Estado: " + resultado.getString(5) + " \n"+
					"\t" + "Cuota abonada: " + resultado.getFloat(6) + " \n" +
					"\t" + "Forma de pago: " + resultado.getString(7) + " \n" +
					"\t" + "Categoría: " + resultado.getString(8);
			
			textDatos.setText(t);
			
		}catch(SQLException eq){
			eq.printStackTrace();
		}
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(textDatos, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(170, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(textDatos, GroupLayout.DEFAULT_SIZE, 333, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		setTitle("Tus Datos");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}