import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.ButtonGroup;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;


public class ConsultarInscripción extends JFrame {
	
	private JPanel contentPane;
	private JTextField tfDni;
	private JTextField tfIdInscripcion;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JButton btnAceptar;
	ResultSet comprobar;
	private JButton btnAtrs;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultarInscripción frame = new ConsultarInscripción();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ConsultarInscripción() {
		try {
		//Conexi�n a la BD
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		//Ruta absoluta o relativa como parámetro de getConnection
		Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
		final Statement s = conn.createStatement();
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 270, 288);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setTitle("Consultar Inscripción");
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		
		JLabel lblIntroduceTuIdentificacin = new JLabel("\u00BFC\u00F3mo quieres identificarte?");
		
		// DNI
		JRadioButton rdbtnDni = new JRadioButton("DNI");
		
		buttonGroup.add(rdbtnDni);
		tfDni = new JTextField();
		tfDni.setColumns(10);
		
		
		//Id_Inscripci�n
		JRadioButton rdbtnIdInscripcion = new JRadioButton("Id Inscripci\u00F3n");
		rdbtnIdInscripcion.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (rdbtnIdInscripcion.isSelected()){
					
					tfIdInscripcion.setEnabled(true);
					btnAceptar.setEnabled(true);
					
				}
				else tfIdInscripcion.setEnabled(false);
			}
		});
		buttonGroup.add(rdbtnIdInscripcion);
		tfIdInscripcion = new JTextField();
		tfIdInscripcion.setColumns(10);
		
		
		rdbtnDni.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				if (rdbtnDni.isSelected()){
					
					tfDni.setEnabled(true);
					btnAceptar.setEnabled(true);
					
				}
				else tfDni.setEnabled(false);
			}
		});
		//Boton Aceptar
		btnAceptar = new JButton("Aceptar");
		btnAceptar.setEnabled(false);
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
				
				if (tfDni.getText().length() != 0){
					
				
				s.execute("SELECT * FROM Atleta WHERE( DNI='" + tfDni.getText() + "')");
				comprobar = s.getResultSet();


				//EL DNI es incorrecto 

				if (comprobar.next()==false){
					tfDni.setText("");
					
					JOptionPane.showMessageDialog(null, " El DNI introducido es incorrecto ","Error",JOptionPane.INFORMATION_MESSAGE);

				}

				//El DNI es correcto y el atleta existe en la BD
				else{
					
					EligeCompeticion n = new EligeCompeticion(tfDni.getText());
					n.setVisible(true);
					ConsultarInscripción.this.dispose();
					
				}
				}
				else if (tfIdInscripcion.getText().length() != 0){
					
					s.execute("SELECT Id_atleta FROM Inscripción WHERE( Id_inscripción='" + tfIdInscripcion.getText() + "')"); 
					comprobar = s.getResultSet();


					//No existe el Id_inscripción en la BD

					if (comprobar.next() == false){
						tfIdInscripcion.setText("");

						JOptionPane.showMessageDialog(null, " El Id introducido es incorrecto ","Error",JOptionPane.INFORMATION_MESSAGE);

					}
					//El Id_inscripción existe, se enseña los datos de la competición

					else {
						DatosConsultadosIdIns n = new DatosConsultadosIdIns(tfIdInscripcion.getText());
						n.setVisible(true);
						ConsultarInscripción.this.dispose();
						
					}
					}
				
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			}
		});
		
		btnAtrs = new JButton("Atrás");
		btnAtrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Atleta n = new Atleta();
				n.setVisible(true);
				ConsultarInscripción.this.dispose();
			}
		});
		

		
		
		//Layout
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(40)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(rdbtnDni)
								.addComponent(rdbtnIdInscripcion)
								.addComponent(tfDni)
								.addComponent(tfIdInscripcion, GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(btnAtrs)
									.addGap(18)
									.addComponent(btnAceptar, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(28)
							.addComponent(lblIntroduceTuIdentificacin, GroupLayout.PREFERRED_SIZE, 208, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(32, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblIntroduceTuIdentificacin)
					.addGap(18)
					.addComponent(rdbtnDni)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(tfDni, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(rdbtnIdInscripcion)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(tfIdInscripcion, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(29)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAtrs)
						.addComponent(btnAceptar))
					.addContainerGap(30, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		}//fin del try de la funcion 
		catch(Exception ex){
		ex.printStackTrace();
		}//fin del catch funci�n 
	}
}
