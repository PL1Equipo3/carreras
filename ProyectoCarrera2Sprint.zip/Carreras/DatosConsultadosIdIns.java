import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class DatosConsultadosIdIns extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run(String ID) {
				try {
					DatosConsultadosIdIns frame = new DatosConsultadosIdIns(ID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DatosConsultadosIdIns(final String ID) {
		try {
			//Conexi�n a la BD
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Ruta absoluta o relativa como parámetro de getConnection
			Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
			final Statement s = conn.createStatement();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 495, 334);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		
		
		
		//Donde Escribiremos los datos
		JTextArea textDatos = new JTextArea();
		
		
		//Obtener los datos 
		try{
			//Obtenemos la competición de la que se quiere los datos mediante el Id_inscripción

			s.execute("SELECT Id_competición FROM Inscripción WHERE( Id_inscripción='" + ID + "')"); 
			ResultSet CompeticionID = s.getResultSet(); 
			CompeticionID.next();
			
			// Se obtiene todos los datos de dicha competición

			s.execute("SELECT Nombre, Apellidos, [Id_inscripción], [Fecha inscripción], Estado, [Cuota abonada], [Forma de pago], Categoría "
					+ "FROM Atleta INNER JOIN Inscripción  "
					+ "ON Inscripción.Id_atleta=Atleta.DNI "
					+ "WHERE (Inscripción.Id_competición = '" + CompeticionID.getString(1) + "' AND Inscripción.Id_inscripción='" + ID + "')");
			ResultSet resultado = s.getResultSet();
			resultado.next();
			//Mostramos al atleta los datos de su consulta

			String t ="Tus datos para la competción " + CompeticionID.getString(1) + " son los siguientes:";
			t=t + "\n\t    " + "Nombre: "+ resultado.getString(1) + " \n" +
					"\t    " + "Apellidos: " + resultado.getString(2) + " \n" + 
					"\t    " + "Id_inscripción: " + resultado.getString(3) + " \n" +
					"\t    " + "Fecha inscripción: " + resultado.getDate(4) + " \n" +
					"\t    " + "Estado: " + resultado.getString(5) + " \n"+
					"\t    " + "Cuota abonada: " + resultado.getFloat(6) + " \n" +
					"\t    " + "Forma de pago: " + resultado.getString(7) + " \n" +
					"\t    " + "Categoría: " + resultado.getString(8);
			
			textDatos.setText(t);
			
		}catch(SQLException eq){
			eq.printStackTrace();
		}
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Datos consultados correctamente","Éxito",JOptionPane.INFORMATION_MESSAGE);
				DatosConsultadosIdIns.this.dispose();
			}
		});
		
		JButton btnVolverParaHacer = new JButton("Volver  para hacer otra consulta");
		btnVolverParaHacer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ConsultarInscripción n = new  ConsultarInscripción();
				n.setVisible(true);
				DatosConsultadosIdIns.this.dispose();
				
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(textDatos, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addGap(50)
					.addComponent(btnVolverParaHacer)
					.addPreferredGap(ComponentPlacement.RELATED, 195, Short.MAX_VALUE)
					.addComponent(btnAceptar)
					.addGap(64))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(textDatos, GroupLayout.PREFERRED_SIZE, 229, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAceptar)
						.addComponent(btnVolverParaHacer))
					.addContainerGap(19, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		setTitle("Tus Datos");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}