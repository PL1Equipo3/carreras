import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.ListSelectionModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class EligeCompeticion extends JFrame {

	private JPanel contentPane;
	public static  DefaultListModel model;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run(String Dni) {
				try {
					EligeCompeticion frame = new EligeCompeticion(Dni);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		});
	}

/**
	 * Create the frame.
	 */
	public EligeCompeticion(final String Dni) {
		
		try {
			//Conexión a la BD
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Ruta absoluta o relativa como parÃ¡metro de getConnection
			Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
			final Statement s = conn.createStatement();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 309, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
				
		
		 
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		
		
		
		JLabel lblCompeticiones = new JLabel("Las competiciones en las que estas inscrito con el DNI: "+Dni+"");
		
		//LIsta 
		JList listCompeticiones = new JList();
		
		
		//Boton de ver Datos
		JButton btnVerDatos = new JButton("Ver Datos");
		
		
		btnVerDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int selected = listCompeticiones.getSelectedIndex();
				String CompeticionEle = model.getElementAt(selected).toString();
				String DNI = Dni;
				
				DatosCompeticionElegida n = new DatosCompeticionElegida(CompeticionEle,DNI);
				n.setVisible(true);
				EligeCompeticion.this.dispose();
			}
		});
		
		
		listCompeticiones.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent arg0) {
				if (model.isEmpty()){
					btnVerDatos.setEnabled(false);
				}
				else{
					btnVerDatos.setEnabled(true);
				}
			}
		});
		//modelo de la lista
		model = new DefaultListModel();
		listCompeticiones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listCompeticiones.setModel(model);
		
		
		
		//Obtenemos las Competiciones según el DNI
		//Se buscan las competiciones en las que esta  inscrito o preinscrito el atleta
		try{
		s.execute("SELECT Id_competición FROM Inscripción WHERE (Id_atleta='" + Dni + "')");
		ResultSet competicion = s.getResultSet();

		//Obtener el numero de competiciones en las que esta inscrito o preinscrito un atleta que este en la base de datos
		//si no esta inscrito o preinscrito en ninguna se le informa

		s.execute("SELECT COUNT(Id_competición) FROM Inscripción WHERE (Id_atleta='" + Dni +"')");
		ResultSet numcomp = s.getResultSet();
		numcomp.next();

		//El atleta esta inscrito o preinscrito en almenos una competición

		if (numcomp.getInt(1) != 0) {
			//Muestra todas las competiciones en las que el atleta está inscrito
			while((competicion.next()))
			{
				model.addElement(competicion.getString(1));
			}
		
			
		}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		
		
		
		
		
		//Layout
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(25)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblCompeticiones, GroupLayout.PREFERRED_SIZE, 301, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
							.addComponent(btnVerDatos, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(listCompeticiones, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE)))
					.addGap(93))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblCompeticiones, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(listCompeticiones, GroupLayout.PREFERRED_SIZE, 151, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnVerDatos)
					.addContainerGap(15, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		setTitle("Elige Una Competición");
		}
		 catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
}