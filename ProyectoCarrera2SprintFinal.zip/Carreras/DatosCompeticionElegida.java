import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;


public class DatosCompeticionElegida extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run(String Comp, String dni) {
				try {
					DatosCompeticionElegida frame = new DatosCompeticionElegida(Comp, dni);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DatosCompeticionElegida(final String Comp, final String dni) {
		try {
			//Conexi�n a la BD
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Ruta absoluta o relativa como parámetro de getConnection
			Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
			final Statement s = conn.createStatement();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 599, 297);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		
		JLabel lblEscrito = new JLabel("");
		JLabel lblNombre = new JLabel("Nombre:");
		
		JLabel lblApellidos = new JLabel("Apellidos:");
		
		JLabel lblIdinscripcin = new JLabel("Id_inscripción:");
		
		JLabel lblFechaInscripcin = new JLabel("Fecha inscripción:");
		
		JLabel lblEstado = new JLabel("Estado:");
		
		JLabel lblCuotaAbonada = new JLabel("Cuota abonada:");
		
		JLabel lblFormaDePago = new JLabel("Forma de pago:");
		
		JLabel lblCategora = new JLabel("Categoría:");
		
		JLabel lblcontnomb = new JLabel("");
		
		JLabel lblcontID = new JLabel("");
		
		JLabel lblcntEstado = new JLabel("");
		
		JLabel lblcntPago = new JLabel("");
		
		JLabel lblcntApellido = new JLabel("");
		
		JLabel lblFecha = new JLabel("");
		
		JLabel lblCuota = new JLabel("");
		
		JLabel lblCategoria = new JLabel("");
		
		//Obtener los datos 
		try{
			
			
			// Se obtiene todos los datos de dicha competición

			s.execute("SELECT Nombre, Apellidos, [Id_inscripción], [Fecha inscripción], Estado, [Cuota abonada], [Forma de pago], Categoría "
					+ "FROM Atleta INNER JOIN Inscripción  "
					+ "ON Inscripción.Id_atleta=Atleta.DNI "
					+ "WHERE (Inscripción.Id_competición = '" + Comp + "' AND Inscripción.Id_atleta='" + dni + "')");
			ResultSet resultado = s.getResultSet();
			resultado.next();
			String cuota = resultado.getFloat(6)+"";
			
			//Mostramos al atleta los datos de su consulta
			
			lblEscrito.setText("Tus datos para la competción " + Comp + " son los siguientes:");
			lblcontnomb.setText(resultado.getString(1));
			lblcntApellido.setText(resultado.getString(2));
			lblcontID.setText(resultado.getString(3));
			lblcntEstado.setText(resultado.getString(5));
			lblcntPago.setText(resultado.getString(7));
			lblCategoria.setText(resultado.getString(8));
			lblCuota.setText(cuota);
			lblFecha.setText((resultado.getDate(4)).toString());

			
			
		}catch(SQLException eq){
			eq.printStackTrace();
		}
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Datos consultados correctamente","Éxito",JOptionPane.INFORMATION_MESSAGE);
				DatosCompeticionElegida.this.dispose();
			}
		});
		
		JButton btnVolverParaHacer = new JButton("Volver para hacer otra consulta");
		btnVolverParaHacer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ConsultarInscripción n = new  ConsultarInscripción();
				n.setVisible(true);
				DatosCompeticionElegida.this.dispose();
				
			}
		});
		
		
		
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(29)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblEscrito)
						.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
							.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
								.addComponent(btnVolverParaHacer)
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnAceptar, GroupLayout.PREFERRED_SIZE, 104, GroupLayout.PREFERRED_SIZE))
							.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
								.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_panel.createSequentialGroup()
										.addComponent(lblApellidos)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(lblcntApellido, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE))
									.addGroup(gl_panel.createSequentialGroup()
										.addComponent(lblNombre)
										.addGap(18)
										.addComponent(lblcontnomb, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE))
									.addGroup(gl_panel.createSequentialGroup()
										.addComponent(lblEstado)
										.addPreferredGap(ComponentPlacement.UNRELATED)
										.addComponent(lblcntEstado, GroupLayout.PREFERRED_SIZE, 147, GroupLayout.PREFERRED_SIZE))
									.addGroup(gl_panel.createSequentialGroup()
										.addComponent(lblFormaDePago)
										.addGap(5)
										.addComponent(lblcntPago, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)))
								.addGap(18)
								.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
									.addGroup(gl_panel.createSequentialGroup()
										.addComponent(lblCuotaAbonada)
										.addGap(18)
										.addComponent(lblCuota, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addGroup(gl_panel.createSequentialGroup()
										.addComponent(lblCategora)
										.addGap(18)
										.addComponent(lblCategoria, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addGroup(gl_panel.createSequentialGroup()
										.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
											.addComponent(lblIdinscripcin, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
											.addComponent(lblFechaInscripcin, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
										.addGap(18)
										.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
											.addComponent(lblcontID, GroupLayout.PREFERRED_SIZE, 207, GroupLayout.PREFERRED_SIZE)
											.addComponent(lblFecha, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))))
					.addGap(22))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(27)
					.addComponent(lblEscrito)
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addComponent(lblNombre, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblcontnomb, GroupLayout.DEFAULT_SIZE, 14, Short.MAX_VALUE)
							.addComponent(lblIdinscripcin)
							.addComponent(lblcontID, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFechaInscripcin)
						.addComponent(lblFecha, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblApellidos, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(lblcntApellido, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(18, 18, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblEstado)
							.addComponent(lblcntEstado, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblCuotaAbonada)
							.addComponent(lblCuota, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblFormaDePago)
							.addComponent(lblcntPago, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblCategora)
							.addComponent(lblCategoria, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE)))
					.addGap(38)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnVolverParaHacer)
						.addComponent(btnAceptar))
					.addGap(31))
		);
		panel.setLayout(gl_panel);
		setTitle("Tus Datos");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}