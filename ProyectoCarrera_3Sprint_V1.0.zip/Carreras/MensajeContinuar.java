import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MensajeContinuar extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String Competición, String Fecha, NuevaInscripcion v) {
		try {
			MensajeContinuar dialog = new MensajeContinuar(Competición, Fecha, v);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public MensajeContinuar(String Competición, String Fecha, NuevaInscripcion v) {
		setBounds(100, 100, 450, 173);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblUstedYaEst = new JLabel("Usted ya está inscrito en la competición "+Competición+" el día "+Fecha+".");
		lblUstedYaEst.setHorizontalAlignment(SwingConstants.CENTER);
		lblUstedYaEst.setBounds(10, 30, 414, 14);
		contentPanel.add(lblUstedYaEst);
		
		JLabel lbldeseaContinuar = new JLabel("¿Desea continuar?");
		lbldeseaContinuar.setHorizontalAlignment(SwingConstants.CENTER);
		lbldeseaContinuar.setBounds(10, 71, 414, 14);
		contentPanel.add(lbldeseaContinuar);
		{
			JPanel buttonPane = new JPanel();
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			buttonPane.setLayout(new BorderLayout(0, 0));
			{
				JButton btCancelar = new JButton("Cancelar");
				btCancelar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						InscripcionesMain n = new InscripcionesMain();
						n.setVisible(true);
						MensajeContinuar.this.dispose();
						v.dispose();
					}
				});
				btCancelar.setActionCommand("OK");
				buttonPane.add(btCancelar, BorderLayout.WEST);
				getRootPane().setDefaultButton(btCancelar);
			}
			{
				JButton btContinuar = new JButton("Continuar");
				btContinuar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						MensajeContinuar.this.dispose();
					}
				});
				btContinuar.setActionCommand("Cancel");
				buttonPane.add(btContinuar, BorderLayout.EAST);
			}
		}
	}
}
