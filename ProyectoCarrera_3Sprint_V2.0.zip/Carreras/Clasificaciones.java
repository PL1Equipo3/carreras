import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.AbstractListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;

public class Clasificaciones extends JFrame {

	private JPanel contentPane;
	private static Connection conn;
	private static Statement s;
	public DefaultListModel<String> model;
	private static File archivo;
	private static PrintWriter pw = null;
	
	/**
	 * Launch the application.
	 */
	public static void main(String ID, String ruta) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Clasificaciones frame = new Clasificaciones(ID, ruta);
					frame.setVisible(true);
					//CalcularClasificaciones("Travesera-13",frame, "C:/Users/usuario.Lenovo-PC/Desktop/PruebaInformación.txt");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	/**
	 * Create the frame.
	 * @param ruta 
	 * @param ID 
	 */
	public Clasificaciones(String ID, String ruta) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 529, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 513, 297);
		contentPane.add(panel);
		
		JLabel lblNewLabel = new JLabel("Clasificaciones:");
		lblNewLabel.setBounds(10, 11, 195, 31);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 53, 414, 197);
		
		model = new DefaultListModel();
		JList list = new JList();
		list.setModel(model);
		scrollPane.setViewportView(list);
		panel.setLayout(null);
		panel.add(lblNewLabel);
		panel.add(scrollPane);
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Organizador n = new Organizador();
				n.setVisible(true);
				Clasificaciones.this.dispose();
			}
		});
		btnAceptar.setBounds(414, 261, 89, 23);
		panel.add(btnAceptar);
		
		System.out.println(ID);
		System.out.println(ruta);
		CalcularClasificaciones(ID,this,ruta);
	}
	
	public static void CalcularClasificaciones(String IdCompeticion, Clasificaciones clas, String out){
		//Conexión a la BD
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		//Ruta absoluta o relativa como parÃ¡metro de getConnection
		conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
		s = conn.createStatement();
	
		pw =new PrintWriter(new FileWriter(out));
		ResultSet Clasificación;
		ResultSet Número;
		String orden;
		
		orden = "SELECT COUNT(*) "
				+ "FROM (Inscripción INNER JOIN Atleta ON Inscripción.Id_atleta = Atleta.DNI)"
				+ "WHERE(Id_competición = '"+IdCompeticion+"' AND Estado = 'Finalizado') ";
		
		s.execute(orden);
		Número = s.getResultSet();
		Número.next();
		int cuenta = Número.getInt(1);
		
		
		//POR CATEGORÍAS
		
		orden = "SELECT Nombre, Apellidos, Sexo, Categoría, [Tiempo de llegada] "
				+ "FROM (Inscripción INNER JOIN Atleta ON Inscripción.Id_atleta = Atleta.DNI)"
				+ "WHERE(Id_competición = '"+IdCompeticion+"' AND Estado = 'Finalizado') "
						+ "ORDER BY Sexo DESC, Categoría , [Tiempo de llegada] ";
				 
		
		s.execute(orden);
		Clasificación = s.getResultSet();

		if(!Clasificación.next()){
			System.out.println("No hay corredores");
		}
		else{
		
		String Sex=Clasificación.getString(3);
		String Cat=Clasificación.getString(4);
		int Posición = 1;
		
		System.out.println("Clasificaciones por categorías:");
		clas.model.addElement("Clasificaciones por categorías:");
		clas.model.addElement(" ");
		pw.println("Clasificaciones por categorías:");
		pw.println();
		
		System.out.println("-----------"+Sex+"-----------");
		clas.model.addElement("-----------"+Sex+"-----------");
		clas.model.addElement(" ");
		pw.println("-----------"+Sex+"-----------");
		pw.println();
		
		System.out.println("-----------"+Cat+"-----------");
		clas.model.addElement("-----------"+Cat+"-----------");
		pw.println("-----------"+Cat+"-----------");
		
		System.out.println("Nombre - Apellidos - Tiempo - Posición");
		clas.model.addElement("Nombre - Apellidos - Tiempo - Posición");
		pw.println("Nombre - Apellidos - Tiempo - Posición");
		
		do{
			if(!Clasificación.getString(3).equals(Sex)){
				Sex=Clasificación.getString(3);
				
				System.out.println("-----------"+Sex+"-----------");
				clas.model.addElement(" ");
				clas.model.addElement("-----------"+Sex+"-----------");
				pw.println();
				pw.println("-----------"+Sex+"-----------");
				
				if(Clasificación.getString(4).equals(Cat)){
					
					System.out.println("-----------"+Cat+"-----------");
					clas.model.addElement(" ");
					clas.model.addElement("-----------"+Cat+"-----------");
					pw.println();
					pw.println("-----------"+Cat+"-----------");
					System.out.println("Nombre - Apellidos - Tiempo - Posición");
					clas.model.addElement("Nombre - Apellidos - Tiempo - Posición");
					pw.println("Nombre - Apellidos - Tiempo - Posición");
					
				}
				Posición=1;
			}
			if(!Clasificación.getString(4).equals(Cat)){
				Cat=Clasificación.getString(4);
				System.out.println("-----------"+Cat+"-----------");
				clas.model.addElement(" ");
				clas.model.addElement("-----------"+Cat+"-----------");
				pw.println();
				pw.println("-----------"+Cat+"-----------");
				System.out.println("Nombre - Apellidos - Tiempo - Posición");
				clas.model.addElement("Nombre - Apellidos - Tiempo - Posición");
				pw.println("Nombre - Apellidos - Tiempo - Posición");
				Posición=1;
			}
			System.out.println(Clasificación.getString(1)+" - "+Clasificación.getString(2)+" - "+
					Clasificación.getTime(5)+" - "+Posición);
			clas.model.addElement(Clasificación.getString(1)+" - "+Clasificación.getString(2)+" - "+
					Clasificación.getTime(5)+" - "+Posición);
			pw.println(Clasificación.getString(1)+" - "+Clasificación.getString(2)+" - "+
					Clasificación.getTime(5)+" - "+Posición);
			cuenta--;
			Clasificación.next();
			Posición++;
			
		}while(cuenta!=0);
		}
		
		
		//CATEGORÍA ABSOLUTA
		cuenta = Número.getInt(1);;
		
		orden = "SELECT Nombre, Apellidos, Sexo, Categoría, [Tiempo de llegada] "
				+ "FROM (Inscripción INNER JOIN Atleta ON Inscripción.Id_atleta = Atleta.DNI)"
				+ "WHERE(Id_competición = '"+IdCompeticion+"' AND Estado = 'Finalizado') "
						+ "ORDER BY Sexo DESC, [Tiempo de llegada] ";
				 
		
		s.execute(orden);
		Clasificación = s.getResultSet();

		if(!Clasificación.next()){
			System.out.println("No hay corredores");
		}
		else{
		
		String Sex=Clasificación.getString(3);
		int Posición = 1;
		
		System.out.println("Clasificaciones absolutas:");
		clas.model.addElement(" ");
		clas.model.addElement("Clasificaciones absolutas:");
		clas.model.addElement(" ");
		pw.println();
		pw.println("Clasificaciones absolutas:");
		pw.println();
		
		System.out.println("-----------"+Sex+"-----------");
		clas.model.addElement("-----------"+Sex+"-----------");
		pw.println("-----------"+Sex+"-----------");
		
		System.out.println("Nombre - Apellidos - Tiempo - Posición - Categoría");
		clas.model.addElement("Nombre - Apellidos - Tiempo - Posición - Categoría");
		pw.println("Nombre - Apellidos - Tiempo - Posición - Categoría");
		
		do{
			if(!Clasificación.getString(3).equals(Sex)){
				Sex=Clasificación.getString(3);
				
				System.out.println("-----------"+Sex+"-----------");
				clas.model.addElement(" ");
				clas.model.addElement("-----------"+Sex+"-----------");
				pw.println();
				pw.println("-----------"+Sex+"-----------");
				
				Posición=1;
			}
			System.out.println(Clasificación.getString(1)+" - "+Clasificación.getString(2)+" - "+
					Clasificación.getTime(5)+" - "+Posición+" - "+Clasificación.getString(4));
			clas.model.addElement(Clasificación.getString(1)+" - "+Clasificación.getString(2)+" - "+
					Clasificación.getTime(5)+" - "+Posición+" - "+Clasificación.getString(4));
			pw.println(Clasificación.getString(1)+" - "+Clasificación.getString(2)+" - "+
					Clasificación.getTime(5)+" - "+Posición+" - "+Clasificación.getString(4));
			cuenta--;
			Clasificación.next();
			Posición++;
			
		}while(cuenta!=0);
		}
		
		pw.close();
		
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
}
