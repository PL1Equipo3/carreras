import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Atleta extends JFrame {

	private JPanel contentPane;
	private ConsultarInscripción VConsultar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Atleta frame = new Atleta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Atleta() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 471, 245);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblAtleta = new JLabel("Atleta");
		lblAtleta.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblAtleta.setBounds(12, 13, 137, 29);
		panel.add(lblAtleta);
		
		JButton btnInscripcin = new JButton("Inscripci\u00F3n");
		btnInscripcin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InscripcionesMain n = new InscripcionesMain();
				n.setVisible(true);
				Atleta.this.dispose();
			}
		});
		btnInscripcin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnInscripcin.setBounds(12, 80, 109, 40);
		panel.add(btnInscripcin);
		
		JButton btnConsulta = new JButton("Consulta");
		btnConsulta.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnConsulta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ConsultarInscripción n = new ConsultarInscripción();
				n.setVisible(true);
				Atleta.this.dispose();
			}
		});
		btnConsulta.setBounds(155, 80, 109, 40);
		panel.add(btnConsulta);
		
		JButton btnAtrs = new JButton("Atr\u00E1s");
		btnAtrs.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Inicial n = new Inicial();
				n.setVisible(true);
				Atleta.this.dispose();
			}
		});
		btnAtrs.setBounds(334, 160, 101, 29);
		panel.add(btnAtrs);
		
		JButton btClasificaciones = new JButton("Clasificaciones");
		btClasificaciones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FiltrarCompeticion t= new FiltrarCompeticion();
				t.setVisible(true);
				Atleta.this.dispose();
			}
		});
		btClasificaciones.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btClasificaciones.setBounds(301, 80, 134, 40);
		panel.add(btClasificaciones);
	}
}