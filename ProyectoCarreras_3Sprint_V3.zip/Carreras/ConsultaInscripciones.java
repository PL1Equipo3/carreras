import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class ConsultaInscripciones extends JFrame {

	private JPanel contentPane;

	// Conexión con la Base de Datos
	private static Connection conn;
	private static Statement s;
	private static NuevaInscripcion frame;
	private JTable table;

	
	/**
	 * Launch the application.
	 */
	public static void main(ResultSet competición) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultaInscripciones frame = new ConsultaInscripciones(competición);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ConsultaInscripciones(ResultSet competición) {
		try {
			//Conexión a la BD
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Ruta absoluta o relativa como parÃ¡metro de getConnection
			conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
			s = conn.createStatement();
			
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 500, 400);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			
			// Ventana auxiliar Filtros
			Filtros f = new Filtros(competición, this);

			
			JLabel lblCompeticin = new JLabel("Competición");
			lblCompeticin.setBounds(12, 13, 105, 22);
			lblCompeticin.setFont(new Font("Tahoma", Font.PLAIN, 18));

			/******* Información de la competición *******/
			
			// Nombre
			JLabel lblNombre = new JLabel("Nombre:");
			lblNombre.setBounds(22, 48, 56, 16);

			JLabel blNombreTxt = new JLabel(competición.getString(3));
			blNombreTxt.setBounds(90, 48, 138, 16);

			// Edición
			JLabel lblEdicin = new JLabel("Edición: ");
			lblEdicin.setBounds(261, 48, 49, 16);

			JLabel lblEdicinTxt = new JLabel(competición.getString(2));
			lblEdicinTxt.setBounds(322, 48, 138, 16);

			// Fecha de celebración
			JLabel lblFecha = new JLabel("Fecha:");
			lblFecha.setBounds(22, 71, 56, 16);

			JLabel lblFechaTxt = new JLabel(competición.getDate(5).toString());
			lblFechaTxt.setBounds(90, 71, 138, 16);

			// Tipo
			JLabel lblTipo = new JLabel("Tipo:");
			lblTipo.setBounds(261, 71, 56, 16);

			JLabel lblTipoTxt = new JLabel(competición.getString(6));
			lblTipoTxt.setBounds(322, 71, 138, 16);

			// Atletas inscritos
			JLabel lblAtletasInscritos = new JLabel("Atletas inscritos:");
			lblAtletasInscritos.setBounds(22, 125, 105, 16);

			ResultSet res = s.executeQuery("SELECT COUNT(*) FROM Inscripción WHERE (Id_competición='" + competición.getString(1) + "')");
			res.next();
			JLabel lblInscritos = new JLabel(""+res.getInt(1));
			lblInscritos.setBounds(140, 125, 83, 16);

			// Plazas libres
			JLabel lblPlazasLibres = new JLabel("Plazas libres:");
			lblPlazasLibres.setBounds(261, 125, 76, 16);

			// competición.getInt(4)= máximo participantes; res.getInt(1)=número de inscripciones
			JLabel lblPlazas = new JLabel(""+(competición.getInt(4)-res.getInt(1)));
			lblPlazas.setBounds(351, 125, 108, 16);
			
			// Lugar
			JLabel lblLugar = new JLabel("Lugar:");
			lblLugar.setBounds(22, 96, 56, 16);

			JLabel lblLugarTxt = new JLabel(competición.getString(7));
			lblLugarTxt.setBounds(83, 96, 138, 16);

			// Distancia
			JLabel lblDistancia = new JLabel("Distancia:");
			lblDistancia.setBounds(261, 96, 56, 16);

			JLabel lblDistanciaTxt = new JLabel(competición.getString(8));
			lblDistanciaTxt.setBounds(329, 96, 128, 16);
			
			contentPane.setLayout(null);
			contentPane.add(lblCompeticin);
			contentPane.add(lblNombre);
			contentPane.add(blNombreTxt);
			contentPane.add(lblEdicin);
			contentPane.add(lblEdicinTxt);
			contentPane.add(lblFecha);
			contentPane.add(lblFechaTxt);
			contentPane.add(lblTipo);
			contentPane.add(lblTipoTxt);
			contentPane.add(lblAtletasInscritos);
			contentPane.add(lblInscritos);
			contentPane.add(lblPlazasLibres);
			contentPane.add(lblPlazas);
			contentPane.add(lblLugar);
			contentPane.add(lblLugarTxt);
			contentPane.add(lblDistancia);
			contentPane.add(lblDistanciaTxt);
			
			
			
			/******* Lista de Inscripciones *******/
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(22, 154, 435, 148);
			contentPane.add(scrollPane);
			// Por defecto se muestran todos los inscritos tal cual los da la BD
			
			
			String query = "SELECT Atleta.DNI, Atleta.Nombre, Atleta.Apellidos, Atleta.Sexo, "
					+ "Inscripción.Estado, Inscripción.[Fecha inscripción], Inscripción.Categoría "
					+ "FROM Inscripción INNER JOIN Atleta ON (Inscripción.Id_atleta = Atleta.DNI) "
					+ "WHERE (Inscripción.Id_competición='" + competición.getString(1) + "')";
			ResultSet inscripciones = s.executeQuery(query);
			
			ArrayList<String[]> filas = new ArrayList<String[]>();
			while (inscripciones.next()) {
				String [] row = {inscripciones.getString(1), inscripciones.getString(2), inscripciones.getString(3), 
						inscripciones.getString(4), inscripciones.getString(5), inscripciones.getString(6), inscripciones.getString(7)};
				filas.add(row);
			}			
			String[][] a = filas.toArray(new String[filas.size()][]);
			String[] columnas = {"DNI","Nombre", "Apellidos", "Sexo", "Estado inscripción", "Fecha inscripción", "Categoría"};
			
			table = new JTable(a, columnas);
			scrollPane.setViewportView(table);
			
			
			
			/******* Botones *******/
			
			JButton btnAceptar = new JButton("Aceptar");
			btnAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Organizador n = new Organizador();
					n.setVisible(true);
					ConsultaInscripciones.this.dispose();
					f.dispose();
				}
			});
			btnAceptar.setBounds(373, 315, 97, 25);
			contentPane.add(btnAceptar);

			JButton btnFiltrar = new JButton("Filtrar");
			btnFiltrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					f.setVisible(true);
				}
			});
			btnFiltrar.setBounds(12, 315, 97, 25);
			contentPane.add(btnFiltrar);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setTable(ResultSet inscripciones) {
		ArrayList<String[]> filas = new ArrayList<String[]>();
		try {
			while (inscripciones.next()) {
				String [] row = {inscripciones.getString(1), inscripciones.getString(2), inscripciones.getString(3), 
						inscripciones.getString(4), inscripciones.getString(5), inscripciones.getString(6), inscripciones.getString(7)};
				filas.add(row);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}			
		String[][] a = filas.toArray(new String[filas.size()][]);
		String[] columnas = {"DNI","Nombre", "Apellidos", "Sexo", "Estado inscripción", "Fecha inscripción", "Categoría"};
		
		table.setModel(new DefaultTableModel(a, columnas));
	}
}
