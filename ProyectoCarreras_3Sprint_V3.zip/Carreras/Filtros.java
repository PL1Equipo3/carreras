import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JCheckBox;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.ButtonGroup;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Filtros extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup bgOrden = new ButtonGroup();
	private final ButtonGroup bgNombre = new ButtonGroup();
	private final ButtonGroup bgApellidos = new ButtonGroup();
	private final ButtonGroup bgDNI = new ButtonGroup();
	private final ButtonGroup bgFechaNac = new ButtonGroup();
	private final ButtonGroup bgFechaInscr = new ButtonGroup();
	
	private ConsultaInscripciones padre;

	/**
	 * Launch the application.
	 */
	public static void main(ResultSet competición, ConsultaInscripciones p) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Filtros frame = new Filtros(competición, p);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Filtros(ResultSet competición, ConsultaInscripciones p) {
		this.padre = p;
		setBounds(100, 100, 450, 560);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblFiltros = new JLabel("Filtros");
		lblFiltros.setBounds(12, 13, 56, 16);
		lblFiltros.setFont(new Font("Tahoma", Font.PLAIN, 18));
		contentPane.setLayout(null);
		contentPane.add(lblFiltros);
		
		JLabel lblOrdenarPor = new JLabel("Ordenar por: ");
		lblOrdenarPor.setBounds(22, 42, 89, 16);
		contentPane.add(lblOrdenarPor);
		
		JLabel lblFiltrarPor = new JLabel("Filtrar por:");
		lblFiltrarPor.setBounds(22, 235, 84, 16);
		contentPane.add(lblFiltrarPor);
		
		JScrollPane spEstado = new JScrollPane();
		spEstado.setBounds(64, 288, 149, 78);
		contentPane.add(spEstado);
		
		JList listEstado = new JList();
		listEstado.setEnabled(false);
		listEstado.setModel(new AbstractListModel() {
			String[] values = new String[] {"Preinscrito", "Inscrito", "Cancelado", "Finalizado"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		spEstado.setViewportView(listEstado);
		
		JScrollPane spCategoria = new JScrollPane();
		spCategoria.setBounds(258, 288, 149, 174);
		contentPane.add(spCategoria);
		
		JList listCategoria = new JList();
		listCategoria.setEnabled(false);
		spCategoria.setViewportView(listCategoria);
		DefaultListModel model = new DefaultListModel();
		try {
			String Id_comp = competición.getString(1);
			//Conexión a la BD
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Ruta absoluta o relativa como parÃ¡metro de getConnection
			Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
			Statement s = conn.createStatement();
			ResultSet categorías = s.executeQuery("SELECT Categoría.Nombre, Categoría.Sexo FROM Categoría "
					+ "INNER JOIN [Categorías de la competición] ON (Categoría.Id_categoría = [Categorías de la competición].Id_categoría)"
					+ "WHERE ([Categorías de la competición].Id_competición = '" + Id_comp + "')");
			
			while (categorías.next()) {
				model.addElement(categorías.getString(1)+"-"+categorías.getString(2));
			}
			listCategoria.setModel(model);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		JScrollPane spSexo = new JScrollPane();
		spSexo.setBounds(64, 407, 149, 78);
		contentPane.add(spSexo);
		
		JList listSexo = new JList();
		listSexo.setEnabled(false);
		listSexo.setModel(new AbstractListModel() {
			String[] values = new String[] {"Masculino", "Femenino"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		spSexo.setViewportView(listSexo);
		
		
		
		
		JCheckBox chckbxEstado = new JCheckBox("Estado de inscripción:");
		chckbxEstado.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if(chckbxEstado.isSelected()) {
					listEstado.setEnabled(true);
				}
				else {
					listEstado.setEnabled(false);
					listEstado.clearSelection();
				}
			}
		});
		chckbxEstado.setBounds(38, 258, 162, 25);
		contentPane.add(chckbxEstado);
		
		JCheckBox chckbxCategora = new JCheckBox("Categoría:");
		chckbxCategora.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if(chckbxCategora.isSelected()) {
					listCategoria.setEnabled(true);
				}
				else {
					listCategoria.setEnabled(false);
					listCategoria.clearSelection();
				}
			}
		});
		chckbxCategora.setBounds(230, 258, 113, 25);
		contentPane.add(chckbxCategora);
		
		JCheckBox chckbxSexo = new JCheckBox("Sexo");
		chckbxSexo.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if(chckbxSexo.isSelected()) {
					listSexo.setEnabled(true);
				}
				else {
					listSexo.setEnabled(false);
					listSexo.clearSelection();
				}
			}
		});
		chckbxSexo.setBounds(38, 378, 113, 25);
		contentPane.add(chckbxSexo);
		
		
		
		JRadioButton rdbtnAscDni = new JRadioButton("Ascedente");
		rdbtnAscDni.setSelected(true);
		bgDNI.add(rdbtnAscDni);
		rdbtnAscDni.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnAscDni.setEnabled(false);
		rdbtnAscDni.setBounds(203, 126, 98, 25);
		contentPane.add(rdbtnAscDni);
		
		JRadioButton rdbtnDescDni = new JRadioButton("Descendente");
		bgDNI.add(rdbtnDescDni);
		rdbtnDescDni.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnDescDni.setEnabled(false);
		rdbtnDescDni.setBounds(305, 126, 101, 25);
		contentPane.add(rdbtnDescDni);
		
		JRadioButton rdbtnAscApellidos = new JRadioButton("Ascedente");
		rdbtnAscApellidos.setSelected(true);
		bgApellidos.add(rdbtnAscApellidos);
		rdbtnAscApellidos.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnAscApellidos.setEnabled(false);
		rdbtnAscApellidos.setBounds(203, 96, 98, 25);
		contentPane.add(rdbtnAscApellidos);
		
		JRadioButton rdbtnDescApellidos = new JRadioButton("Descendente");
		bgApellidos.add(rdbtnDescApellidos);
		rdbtnDescApellidos.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnDescApellidos.setEnabled(false);
		rdbtnDescApellidos.setBounds(305, 96, 101, 25);
		contentPane.add(rdbtnDescApellidos);
		
		JRadioButton rdbtnAscNombre = new JRadioButton("Ascedente");
		rdbtnAscNombre.setSelected(true);
		bgNombre.add(rdbtnAscNombre);
		rdbtnAscNombre.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnAscNombre.setEnabled(false);
		rdbtnAscNombre.setBounds(203, 66, 98, 25);
		contentPane.add(rdbtnAscNombre);
		
		JRadioButton rdbtnDescNombre = new JRadioButton("Descendente");
		bgNombre.add(rdbtnDescNombre);
		rdbtnDescNombre.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnDescNombre.setEnabled(false);
		rdbtnDescNombre.setBounds(305, 66, 101, 25);
		contentPane.add(rdbtnDescNombre);
		
		JRadioButton rdbtnAscFechaNac = new JRadioButton("Ascedente");
		rdbtnAscFechaNac.setSelected(true);
		bgFechaNac.add(rdbtnAscFechaNac);
		rdbtnAscFechaNac.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnAscFechaNac.setEnabled(false);
		rdbtnAscFechaNac.setBounds(203, 156, 98, 25);
		contentPane.add(rdbtnAscFechaNac);
		
		JRadioButton rdbtnDescFechaNac = new JRadioButton("Descendente");
		bgFechaNac.add(rdbtnDescFechaNac);
		rdbtnDescFechaNac.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnDescFechaNac.setEnabled(false);
		rdbtnDescFechaNac.setBounds(305, 156, 101, 25);
		contentPane.add(rdbtnDescFechaNac);
		
		JRadioButton rdbtnAscFechaInscr = new JRadioButton("Ascedente");
		rdbtnAscFechaInscr.setSelected(true);
		bgFechaInscr.add(rdbtnAscFechaInscr);
		rdbtnAscFechaInscr.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnAscFechaInscr.setEnabled(false);
		rdbtnAscFechaInscr.setBounds(203, 186, 98, 25);
		contentPane.add(rdbtnAscFechaInscr);
		
		JRadioButton rdbtnDescFechaInscr = new JRadioButton("Descendente");
		bgFechaInscr.add(rdbtnDescFechaInscr);
		rdbtnDescFechaInscr.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnDescFechaInscr.setEnabled(false);
		rdbtnDescFechaInscr.setBounds(305, 186, 101, 25);
		contentPane.add(rdbtnDescFechaInscr);
		
		JRadioButton rdbtnNombre = new JRadioButton("Nombre:");
		rdbtnNombre.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				if (rdbtnNombre.isSelected()==true) {
					rdbtnAscNombre.setEnabled(true);
					rdbtnDescNombre.setEnabled(true);
				}
				else{
					rdbtnAscNombre.setEnabled(false);
					rdbtnDescNombre.setEnabled(false);
				}
			}
		});
		bgOrden.add(rdbtnNombre);
		rdbtnNombre.setBounds(37, 66, 127, 25);
		contentPane.add(rdbtnNombre);
		
		JRadioButton rdbtnApellidos = new JRadioButton("Apellidos");
		rdbtnApellidos.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (rdbtnApellidos.isSelected()==true) {
					rdbtnAscApellidos.setEnabled(true);
					rdbtnDescApellidos.setEnabled(true);
				}
				else{
					rdbtnAscApellidos.setEnabled(false);
					rdbtnDescApellidos.setEnabled(false);
				}
			}
		});
		bgOrden.add(rdbtnApellidos);
		rdbtnApellidos.setBounds(37, 96, 127, 25);
		contentPane.add(rdbtnApellidos);
		
		JRadioButton rdbtnDni = new JRadioButton("DNI:");
		rdbtnDni.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (rdbtnDni.isSelected()==true) {
					rdbtnAscDni.setEnabled(true);
					rdbtnDescDni.setEnabled(true);
				}
				else{
					rdbtnAscDni.setEnabled(false);
					rdbtnDescDni.setEnabled(false);
				}
			}
		});
		bgOrden.add(rdbtnDni);
		rdbtnDni.setBounds(37, 126, 127, 25);
		contentPane.add(rdbtnDni);
		
		JRadioButton rdbtnFechaDeNacimiento = new JRadioButton("Fecha de nacimiento:");
		rdbtnFechaDeNacimiento.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (rdbtnFechaDeNacimiento.isSelected()==true) {
					rdbtnAscFechaNac.setEnabled(true);
					rdbtnDescFechaNac.setEnabled(true);
				}
				else{
					rdbtnAscFechaNac.setEnabled(false);
					rdbtnDescFechaNac.setEnabled(false);
				}
			}
		});
		bgOrden.add(rdbtnFechaDeNacimiento);
		rdbtnFechaDeNacimiento.setBounds(38, 156, 149, 25);
		contentPane.add(rdbtnFechaDeNacimiento);
		
		JRadioButton rdbtnFechaDeInscripcin = new JRadioButton("Fecha de inscripción:");
		rdbtnFechaDeInscripcin.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (rdbtnFechaDeInscripcin.isSelected()==true) {
					rdbtnDescFechaInscr.setEnabled(true);
					rdbtnAscFechaInscr.setEnabled(true);
				}
				else{
					rdbtnDescFechaInscr.setEnabled(false);
					rdbtnAscFechaInscr.setEnabled(false);
				}
			}
		});
		bgOrden.add(rdbtnFechaDeInscripcin);
		rdbtnFechaDeInscripcin.setBounds(38, 186, 149, 25);
		contentPane.add(rdbtnFechaDeInscripcin);
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String q = "SELECT Atleta.DNI, Atleta.Nombre, Atleta.Apellidos, Atleta.Sexo, "
						+ "Inscripción.Estado, Inscripción.[Fecha inscripción], Inscripción.Categoría "
						+ "FROM Inscripción INNER JOIN Atleta ON (Inscripción.Id_atleta = Atleta.DNI) ";
						
					q += "WHERE (Inscripción.Id_competición='" + competición.getString(1) + "'";
					// Checkboxes
					if(chckbxEstado.isSelected()) {
						q += " AND (";
						List values = listEstado.getSelectedValuesList();
						for (int i=0; i<values.size(); i++){
							q += " Inscripción.Estado='" + values.get(i) + "'";
							if(i!=values.size()-1){
								q += " OR";
							}
						}	
						q += ")";
					}
					if(chckbxCategora.isSelected()) {
						q += " AND (";
						List values = listCategoria.getSelectedValuesList();
						for (int i=0; i<values.size(); i++){
							String [] cat = values.get(i).toString().split("-");
							q += " Inscripción.Categoría='" + cat[0] + "' AND Atleta.Sexo='" + cat[1] + "'";
							if(i!=values.size()-1){
								q += " OR";
							}
						}
						q += ")";
					}
					if(chckbxSexo.isSelected()) {
						q += " AND (";
						List values = listSexo.getSelectedValuesList();
						for (int i=0; i<values.size(); i++){
							q += " Atleta.Sexo='" + values.get(i) + "'";
							if(i!=values.size()-1){
								q += " OR";
							}
						}
						q += ")";
					}
					q += ")";
					
					
					
					// Radio buttons
					if(rdbtnNombre.isSelected()) {
						q += " ORDER BY Atleta.Nombre";
						if (rdbtnAscNombre.isSelected()) {
							q += " ASC";
						}
						else {
							q += " DESC";
						}
					}
					if(rdbtnApellidos.isSelected()) {
						q += " ORDER BY Atleta.Apellidos";
						if (rdbtnAscApellidos.isSelected()) {
							q += " ASC";
						}
						else {
							q += " DESC";
						}
					}
					if(rdbtnDni.isSelected()) {
						q += " ORDER BY Atleta.Nombre";
						if (rdbtnAscDni.isSelected()) {
							q += " ASC";
						}
						else {
							q += " DESC";
						}
					}
					if(rdbtnFechaDeNacimiento.isSelected()) {
						q += " ORDER BY Atleta.[Fecha nacimiento]";
						if (rdbtnAscFechaNac.isSelected()) {
							q += " ASC";
						}
						else {
							q += " DESC";
						}
					}
					if(rdbtnFechaDeInscripcin.isSelected()) {
						q += " ORDER BY Inscripción.[Fecha inscripción]";
						if (rdbtnAscFechaInscr.isSelected()) {
							q += " ASC";
						}
						else {
							q += " DESC";
						}
					}
					
					//Conexión a la BD
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
					//Ruta absoluta o relativa como parÃ¡metro de getConnection
					Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
					Statement s = conn.createStatement();
					
					ResultSet inscripciones = s.executeQuery(q);
					padre.setTable(inscripciones);
					Filtros.this.setVisible(false);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnAceptar.setBounds(323, 475, 97, 25);
		contentPane.add(btnAceptar);
		
	}
}
