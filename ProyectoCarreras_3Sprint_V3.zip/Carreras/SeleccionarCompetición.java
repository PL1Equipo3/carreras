import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ButtonGroup;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

public class SeleccionarCompetición extends JFrame {

	private JPanel contentPane;
	private JTextField tfLugar;
	private JTextField tfNombre;
	private final ButtonGroup buttonGroupFecha = new ButtonGroup();
	public static  DefaultListModel model;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SeleccionarCompetición frame = new SeleccionarCompetición();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public String dameid(String linea){
		String id ="";
		int i =0;
		
		while ((linea.length() > 0 )  && (linea.charAt(i) != '-') ){
			
			char letra = linea.charAt(i);
			id =id+letra;
			
			i++;
		}
		while ((linea.length() > 0 )  && (linea.charAt(i) != ' ') ){
			
			char letra = linea.charAt(i);
			id =id+letra;
				
			i++;
			}
		return id;
	}	
	/**
	 * Create the frame.
	 */
	public SeleccionarCompetición() {
		
		
		try {
			//Conexión a la BD
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Ruta absoluta o relativa como parÃ¡metro de getConnection
			Connection conn=DriverManager.getConnection("jdbc:ucanaccess://Carreras 2ª versión.accdb");
			final Statement s = conn.createStatement();
			
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 662, 663);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setTitle("Consultar inscripciones de una competición: Seleccionar competición");
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		
		tfLugar = new JTextField();
		tfLugar.setEnabled(false);
		tfLugar.setColumns(10);
		
		tfNombre = new JTextField();
		tfNombre.setEnabled(false);
		tfNombre.setColumns(10);
		
		JComboBox cboxtipocarrera = new JComboBox();
		cboxtipocarrera.setEnabled(false);
		cboxtipocarrera.setModel(new DefaultComboBoxModel(new String[] {"Montaña ", "Carrera Popular"}));
		
		JCheckBox chckbxTipoCarrera = new JCheckBox("Tipo Carrera");
		chckbxTipoCarrera.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				cboxtipocarrera.setEnabled(chckbxTipoCarrera.isSelected());
				
			}
		});
		 //Fecha exacta
		JComboBox cboxdia = new JComboBox();
		cboxdia.setEnabled(false);
		cboxdia.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		cboxdia.setBounds(10, 79, 49, 20);
		panel.add(cboxdia);

		
		JComboBox cboxmes = new JComboBox();
		cboxmes.setEnabled(false);
		cboxmes.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
		cboxmes.setBounds(81, 79, 49, 20);
		panel.add(cboxmes);
		
		JComboBox cboxanyo = new JComboBox();
		cboxanyo.setEnabled(false);
		cboxanyo.setModel(new DefaultComboBoxModel(new String[] {"2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028"}));
		cboxanyo.setBounds(153, 79, 63, 20);
		panel.add(cboxanyo);
		
		
		
		//Fecha inicio 
		JComboBox cbdiaI = new JComboBox();
		cbdiaI.setEnabled(false);
		cbdiaI.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		cbdiaI.setBounds(10, 79, 49, 20);
		panel.add(cbdiaI);
		
		JComboBox cbmesI = new JComboBox();
		cbmesI.setEnabled(false);
		cbmesI.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
		cbmesI.setBounds(81, 79, 49, 20);
		panel.add(cbmesI);
		
		JComboBox cbanyoI = new JComboBox();
		cbanyoI.setEnabled(false);
		cbanyoI.setModel(new DefaultComboBoxModel(new String[] {"2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028"}));
		cbanyoI.setBounds(153, 79, 63, 20);
		panel.add(cbanyoI);
		
		
		//Fecha fin
		JComboBox cbDiaF = new JComboBox();
		cbDiaF.setEnabled(false);
		cbDiaF.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		cbDiaF.setBounds(10, 79, 49, 20);
		panel.add(cbDiaF);
		
		JComboBox cbMesF = new JComboBox();
		cbMesF.setEnabled(false);
		cbMesF.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
		cbMesF.setBounds(81, 79, 49, 20);
		panel.add(cbMesF);
		
		JComboBox cbAnyoF = new JComboBox();
		cbAnyoF.setEnabled(false);
		cbAnyoF.setModel(new DefaultComboBoxModel(new String[] {"2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028"}));
		cbAnyoF.setBounds(153, 79, 63, 20);
		panel.add(cbAnyoF);
		
		JRadioButton rdbtnFechaCompeticin = new JRadioButton("Fecha competición");
		rdbtnFechaCompeticin.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (rdbtnFechaCompeticin.isSelected()){
					
					cboxdia.setEnabled(true);
					cboxmes.setEnabled(true);
					cboxanyo.setEnabled(true);
					
				}
				else {
					cboxdia.setEnabled(false);
					cboxmes.setEnabled(false);
					cboxanyo.setEnabled(false);
				}
			}
		});
		buttonGroupFecha.add(rdbtnFechaCompeticin);
		JRadioButton rdbtnRangoDeFechas = new JRadioButton("Rango de fechas");
		rdbtnRangoDeFechas.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (rdbtnRangoDeFechas.isSelected()){
					cbdiaI.setEnabled(true);
					cbmesI.setEnabled(true);
					cbanyoI.setEnabled(true);
					cbDiaF.setEnabled(true);
					cbMesF.setEnabled(true);
					cbAnyoF.setEnabled(true);
					
				}
				else{	
					cbdiaI.setEnabled(false);
					cbmesI.setEnabled(false);
					cbanyoI.setEnabled(false);
					cbDiaF.setEnabled(false);
					cbMesF.setEnabled(false);
					cbAnyoF.setEnabled(false);
				
				}
			}
		});
		buttonGroupFecha.add(rdbtnRangoDeFechas);
		
		JCheckBox chckbxFecha = new JCheckBox("Fecha");
		chckbxFecha.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				
				if (chckbxFecha.isSelected()){
				rdbtnFechaCompeticin.setEnabled(chckbxFecha.isSelected());
				rdbtnRangoDeFechas.setEnabled(chckbxFecha.isSelected());
				}
				else {
					
					rdbtnFechaCompeticin.setEnabled(false);
					rdbtnRangoDeFechas.setEnabled(false);
					cboxdia.setEnabled(false);
					cboxmes.setEnabled(false);
					cboxanyo.setEnabled(false);
					cbdiaI.setEnabled(false);
					cbmesI.setEnabled(false);
					cbanyoI.setEnabled(false);
					cbDiaF.setEnabled(false);
					cbMesF.setEnabled(false);
					cbAnyoF.setEnabled(false);
					
				}
			}
		});
		
		
		JCheckBox chckbxLugar = new JCheckBox("Lugar:");
		chckbxLugar.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				tfLugar.setEnabled(chckbxLugar.isSelected());
			}
		});
		
		
		JCheckBox chckbxNombre = new JCheckBox("Nombre:");
		chckbxNombre.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				tfNombre.setEnabled(chckbxNombre.isSelected());
			}
		});
		
		
		JLabel lblIntroduzcaLosDatos = new JLabel("Introduzca los datos que conozca para buscar la competición");
		lblIntroduzcaLosDatos.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblSeleccioneUnaDe = new JLabel("Seleccione una de las competiciones:");
		lblSeleccioneUnaDe.setHorizontalAlignment(SwingConstants.CENTER);
		
			
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					boolean primero =true;
					String Consulta = "SELECT Id_competición, Nombre, Edición, Fecha FROM Competición WHERE (";
					String Total = "SELECT COUNT(Nombre) AS Total FROM (SELECT Nombre, Edición, Fecha FROM Competición WHERE (";
					
					if (chckbxNombre.isSelected() && tfNombre.getText().length() != 0){
						String condicionNombre =  " Nombre ='" +tfNombre.getText()+ "'";
						Consulta = Consulta + condicionNombre;
						Total = Total + condicionNombre;
						
						primero = false;
						
					}
					if (chckbxLugar.isSelected() && tfLugar.getText().length() != 0 ){
						if (primero == false){
							String condicionLugar =  "  AND Lugar ='" +tfLugar.getText()+ "'";
							Consulta = Consulta + condicionLugar;
							Total = Total + condicionLugar;
						}else {
							String condicionLugar =  "Lugar ='" +tfLugar.getText()+ "'";
							Consulta = Consulta + condicionLugar;
							Total = Total + condicionLugar;
							primero =false;
						}
					}
					if (chckbxTipoCarrera.isSelected()){
						String condicionMontaña;
						String condicionCPopular;
						if (primero == false){
						
							if (cboxtipocarrera.getSelectedItem().equals("Montaña")){
								condicionMontaña = " AND Tipo ='"+ cboxtipocarrera.getSelectedItem()+"'";
								Consulta = Consulta + condicionMontaña;
								Total = Total + condicionMontaña;
							}
							else{
							condicionCPopular = " AND Tipo ='"+ cboxtipocarrera.getSelectedItem()+"'";
							Consulta = Consulta + condicionCPopular;
							Total = Total + condicionCPopular;
							}
						
						}else {
							if  (cboxtipocarrera.getSelectedItem().equals("Montaña")){
								condicionMontaña = " Tipo ='"+ cboxtipocarrera.getSelectedItem()+"'";
								Consulta = Consulta + condicionMontaña;
								Total = Total + condicionMontaña;
								primero = false;
							}
							else {
								condicionCPopular = " Tipo ='"+ cboxtipocarrera.getSelectedItem()+"'";
								Consulta = Consulta + condicionCPopular;
								Total = Total + condicionCPopular;
								primero = false;
							}
							
							
						}
					}
					if (chckbxFecha.isSelected()){
						String condicionFExacta ;
						String condicionRango;
						if (primero == false){
						if (rdbtnRangoDeFechas.isSelected()){
							
							String diaI = (String) cbdiaI.getSelectedItem();
							String mesI = (String) cbmesI.getSelectedItem();
							String añoI = (String) cbanyoI.getSelectedItem();
							String fechaIni=añoI+"-"+mesI+"-"+diaI;
							
							String diaF = (String) cbDiaF.getSelectedItem();
							String mesF = (String) cbMesF.getSelectedItem();
							String añoF = (String) cbAnyoF.getSelectedItem();
							String fechaFin=añoF+"-"+mesF+"-"+diaF;
							
							condicionRango = " AND (Fecha >=#"+ fechaIni+ "# AND Fecha <= #"+ fechaFin +"#)" ;
							Consulta = Consulta + condicionRango;
							Total = Total + condicionRango;
							
						}else if (rdbtnFechaCompeticin.isSelected()){
							String dia = (String) cboxdia.getSelectedItem();
							String mes = (String) cboxmes.getSelectedItem();
							String año = (String) cboxanyo.getSelectedItem();
							String fechaComp=año+"-"+mes+"-"+dia;
							condicionFExacta = " AND Fecha = #"+ fechaComp+ "#";
							Consulta = Consulta + condicionFExacta;
							Total = Total + condicionFExacta;
						}
						
						}else {
							if (rdbtnRangoDeFechas.isSelected()){
								
								String diaI = (String) cbdiaI.getSelectedItem();
								String mesI = (String) cbmesI.getSelectedItem();
								String añoI = (String) cbanyoI.getSelectedItem();
								String fechaIni=añoI+"-"+mesI+"-"+diaI;
								
								String diaF = (String) cbDiaF.getSelectedItem();
								String mesF = (String) cbMesF.getSelectedItem();
								String añoF = (String) cbAnyoF.getSelectedItem();
								String fechaFin=añoF+"-"+mesF+"-"+diaF;
								
								condicionRango = "Fecha >= #"+ fechaIni+ "# AND Fecha <= #"+ fechaFin +"#" ;
								Consulta = Consulta + condicionRango;
								Total = Total +condicionRango;
								
							}else if (rdbtnFechaCompeticin.isSelected()){
								String dia = (String) cboxdia.getSelectedItem();
								String mes = (String) cboxmes.getSelectedItem();
								String año = (String) cboxanyo.getSelectedItem();
								String fechaComp=año+"-"+mes+"-"+dia;
								condicionFExacta = "Fecha = #"+ fechaComp+ "#";
								Consulta = Consulta + condicionFExacta;
								Total = Total + condicionFExacta;
							}
							
						}
					}
					Consulta = Consulta +")";
					Total = Total +")); ";
					
					s.execute(Consulta);
					ResultSet competicion = s.getResultSet();
					s.execute(Total);
					ResultSet total = s.getResultSet();
					
						
					total.next();

					if (total.getInt(1) != 0){
					model.clear();	
					model.addElement("Id_competición:                             Nombre:                              Edición:                       Fecha:");
					while (competicion.next()){
						
						String ID = competicion.getString(1);
						String Nombre =competicion.getString(2);
						String Edicion = competicion.getString(3);
						String Fecha = competicion.getDate(4).toString();
						
						model.addElement(ID+"                           "+Nombre+"                        "+Edicion+"                      "+Fecha);
						
			
					}
					}
					else if (total.getInt(1) == 0) {
						if (chckbxFecha.isSelected() && rdbtnRangoDeFechas.isSelected()){
							//comprobar que el rango de fechas es correcto
							String diaI =  (String) cbdiaI.getSelectedItem();
							int DiaI = Integer.parseInt(diaI);
							String  mesI = (String) cbmesI.getSelectedItem();
							int MesI = Integer.parseInt(mesI);
							String añoI = (String) cbanyoI.getSelectedItem();
							int AñoI = Integer.parseInt(añoI);
							
							
							String diaF = (String) cbDiaF.getSelectedItem();
							int DiaF = Integer.parseInt(diaF);
							String mesF = (String) cbMesF.getSelectedItem();
							int MesF = Integer.parseInt(mesF);
							String añoF = (String) cbAnyoF.getSelectedItem();
							int AñoF = Integer.parseInt(añoF);
							
							if (AñoI > AñoF){
								JOptionPane.showMessageDialog(null, "Rango de fechas incorrectas","Error",JOptionPane.ERROR_MESSAGE);
								
							}else if (AñoI == AñoF) {
								if ( MesI > MesF){
									JOptionPane.showMessageDialog(null, "Rango de fechas incorrectas","Error",JOptionPane.ERROR_MESSAGE);
			
								}else if (MesI == MesF){
									if(DiaI >= DiaF){
										JOptionPane.showMessageDialog(null, "Rango de fechas incorrectas","Error",JOptionPane.ERROR_MESSAGE);
									
									}
								}
							}
							}
						else{
						
						JOptionPane.showMessageDialog(null, "Busqueda errónea. Revise los filtros,algun dato es incorrecto.","Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					}
				
					
				  catch(SQLException e){
					e.printStackTrace();
				}
				
				
			}
		});
		
		
		JScrollPane scrollPane = new JScrollPane();
		JButton btnAceptar = new JButton("Aceptar");
		
		JList listCompeticion = new JList();
		listCompeticion.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent arg0) {
				if (model.getSize()==0){
					btnAceptar.setEnabled(false);
					JOptionPane.showMessageDialog(null, " No existe ninguna competicion con esas características ","Aviso",JOptionPane.INFORMATION_MESSAGE);
				}
				else{
					btnAceptar.setEnabled(true);
				}
			}
		});
		scrollPane.setViewportView(listCompeticion);
		
		//modelo de la lista
		model = new DefaultListModel();
		listCompeticion.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    listCompeticion.setModel(model);
	    
	    
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int selected = listCompeticion.getSelectedIndex();
				String CompeticionEle = model.getElementAt(selected).toString();
				String Idcom = dameid(CompeticionEle);
				if (CompeticionEle.equals("Id_competición:                             Nombre:                              Edición:                       Fecha:")){
					JOptionPane.showMessageDialog(null, " No ha elegido una competición si no el titulo ","Aviso",JOptionPane.INFORMATION_MESSAGE);
				}else{
				
				try{
				s.execute("SELECT * FROM Competición WHERE ( Id_competición = '"+Idcom+"')");
				ResultSet Competicion = s.getResultSet();
				Competicion.next();
			
				ConsultaInscripciones n = new ConsultaInscripciones(Competicion);
				n.setVisible(true);
				SeleccionarCompetición.this.dispose();
				}catch(SQLException e){
					e.printStackTrace();
				}
				}
			}
		});
		
		JButton btnAtrs = new JButton("Atrás");
		btnAtrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Organizador n = new Organizador();
				n.setVisible(true);
				SeleccionarCompetición.this.dispose();
			}
		});
	
		JLabel lblFechaExacta = new JLabel("Fecha competición:");
		
		JLabel lblSeleccioneUnRango = new JLabel("Rango de fechas:");
		
		JLabel lblFechaInicial = new JLabel("Fecha Inicial:");
		
		JLabel lblFechaFinal = new JLabel("Fecha Final:");
		
		
		JSeparator separator = new JSeparator();
		
		JSeparator separator_1 = new JSeparator();
		
		
		JSeparator separator_2 = new JSeparator();
		
		JSeparator separator_3 = new JSeparator();
		
		JLabel ldia = new JLabel("Día");
		
		JLabel lmes = new JLabel("Mes");
		
		JLabel lanyo = new JLabel("Año");
		
		JLabel lblDiaI = new JLabel("Día");
		
		JLabel lMesI = new JLabel("Mes");
		
		JLabel lblAnyoI = new JLabel("Año");
		
		
		
		JLabel ldiaF = new JLabel("Día");
		
		JLabel lMesF = new JLabel("Mes");
		
		JLabel lAnyoF = new JLabel("Año");
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(19)
							.addComponent(lblIntroduzcaLosDatos, GroupLayout.PREFERRED_SIZE, 610, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(19)
							.addComponent(chckbxNombre, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(6)
							.addComponent(tfNombre, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE))
						.addComponent(separator, GroupLayout.PREFERRED_SIZE, 649, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(19)
							.addComponent(chckbxLugar, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(6)
							.addComponent(tfLugar, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE))
						.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, 649, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(19)
							.addComponent(chckbxTipoCarrera, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(6)
							.addComponent(cboxtipocarrera, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(540)
							.addComponent(btnBuscar, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(19)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblSeleccioneUnRango, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_panel.createSequentialGroup()
									.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
										.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
											.addGroup(gl_panel.createSequentialGroup()
												.addGap(91)
												.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
													.addGroup(gl_panel.createSequentialGroup()
														.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
															.addComponent(lblFechaFinal)
															.addComponent(lblFechaInicial))
														.addGap(36)
														.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
															.addComponent(lblDiaI, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)
															.addComponent(ldiaF, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)
															.addComponent(cbdiaI, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)))
													.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
														.addComponent(ldia, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(cboxdia, Alignment.TRAILING, 0, 66, Short.MAX_VALUE))))
											.addComponent(lblFechaExacta, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE))
										.addComponent(cbDiaF, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE))
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panel.createSequentialGroup()
											.addGap(229)
											.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
												.addComponent(lanyo, GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
												.addComponent(cboxanyo, 0, 71, Short.MAX_VALUE)
												.addComponent(lblAnyoI, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(cbanyoI, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(lAnyoF, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(cbAnyoF, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
										.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
											.addGroup(gl_panel.createSequentialGroup()
												.addGap(75)
												.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
													.addComponent(cbMesF, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
													.addComponent(cbmesI, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
													.addComponent(lMesF, GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
													.addComponent(lMesI, GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)))
											.addGroup(gl_panel.createSequentialGroup()
												.addGap(74)
												.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
													.addComponent(lmes, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
													.addComponent(cboxmes, 0, 74, Short.MAX_VALUE))))))
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(chckbxFecha, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
									.addGap(2)
									.addComponent(rdbtnFechaCompeticin, GroupLayout.PREFERRED_SIZE, 137, GroupLayout.PREFERRED_SIZE)
									.addGap(32)
									.addComponent(rdbtnRangoDeFechas, GroupLayout.PREFERRED_SIZE, 136, GroupLayout.PREFERRED_SIZE))))
						.addComponent(lblSeleccioneUnaDe, GroupLayout.PREFERRED_SIZE, 620, GroupLayout.PREFERRED_SIZE)
						.addComponent(separator_2, GroupLayout.PREFERRED_SIZE, 649, GroupLayout.PREFERRED_SIZE)
						.addComponent(separator_3, GroupLayout.PREFERRED_SIZE, 638, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(19)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 610, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(btnAtrs, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(btnAceptar, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE)))))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(11)
					.addComponent(lblIntroduzcaLosDatos)
					.addGap(21)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(chckbxNombre)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(1)
							.addComponent(tfNombre, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(9)
					.addComponent(separator, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(10)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(chckbxLugar)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(1)
							.addComponent(tfLugar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(9)
					.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, 6, GroupLayout.PREFERRED_SIZE)
					.addGap(5)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(chckbxTipoCarrera)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(1)
							.addComponent(cboxtipocarrera, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(11)
					.addComponent(separator_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(7)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(chckbxFecha)
						.addComponent(rdbtnFechaCompeticin)
						.addComponent(rdbtnRangoDeFechas))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lmes)
								.addComponent(lanyo)
								.addComponent(ldia))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(cboxdia, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(cboxmes, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(cboxanyo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addComponent(lblFechaExacta))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblSeleccioneUnRango)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFechaInicial)
						.addComponent(lblDiaI)
						.addComponent(lMesI)
						.addComponent(lblAnyoI))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(cbmesI, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(cbanyoI, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(cbdiaI, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblFechaFinal)
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(ldiaF)
								.addComponent(lMesF)
								.addComponent(lAnyoF))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(cbMesF, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(cbAnyoF, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(cbDiaF, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
					.addGap(18)
					.addComponent(separator_3, GroupLayout.PREFERRED_SIZE, 3, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnBuscar)
					.addGap(1)
					.addComponent(lblSeleccioneUnaDe)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAtrs)
						.addComponent(btnAceptar))
					.addGap(28))
		);
		panel.setLayout(gl_panel);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
